<?php 
//print($_POST['username']);
include('validaterule.php');
include('validationerror.php');
include('validation.php');
include('connDriver.php');
if(isset($_POST['sign_up'])){
    print_r($_POST);
    $input=new validateinput($_POST,$con);
    $formvalue=$input->validateFunc();
    $input->checkError();
    if ($input->checkError()== false) {
        # code...
        $sql = "SELECT * FROM tbl_users WHERE email= '$_POST["email"]'";
        $query=$con->query($sql);
        if(mysqli_num_rows($query)>0){
            $_SESSION['error'] = 'User Email already exists.';
            header('LOCATION:'.$_SERVER['HTTP_REFERER']);
        }
    }
   
}

// login if statement
if(isset($_POST['sign_in'])){
              
    if(empty($_POST['email'])){
        $_SESSION['error']='the email field cannot be empty';
        header('Location: ../views/auth/login.php') ;
    }
    else{
 
if (strlen($_POST['email'])> 4) {

    $email =isValidated( $_POST['email']);
    if(filter_var($email,FILTER_VALIDATE_EMAIL)){
        $check = true;
    }
    else{
        $_SESSION['error'] = 'This is not a valid email address';
        header('Location: ../views/auth/login.php');
    }
    
}
else{
    $_SESSION['error'] ='email is too short';
    header('Location: ../views/auth/login.php');
}
    }
    if(empty($_POST['password'])){
        $_SESSION['error'] = 'The password field cannot be empty.';
        header('Location: ../views/auth/login.php');
     
    }
    else{
        if(strlen($_POST['password'])>= 6){
            $password =$_POST['password'];
        $check = true; 
        } else{
            $_SESSION['error'] ='Password too short.' ;
        header('Location: ../views/auth/login.php');
        }
      
    }
   
}

?>