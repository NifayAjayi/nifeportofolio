<?php
session_start();
$check=true;

function isValidated($value)
{
    $value = isEmpty($value);
    $value= trim($value);
    $value = stripslashes($value);
    $value=(strlen($value)> 3) ? $value:$GLOBALS['check']=false;
   $value= htmlspecialchars($value);
   return $value;

}
function isEmpty($data)
{
    if (empty($data)){
        $GLOBALS['check']=false;
    }
    else{
        return $data;
        
    }

}
function isValidEmail($value) {
    if (!filter_var($value, FILTER_VALIDATE_EMAIL)){
        $check = false;
     $_SESSION['error'] = 'Invalid email format.';
    }
    return $value;
}
class validateinput extends  validationerr{
    public static $fields=[];
    public function validateFunc()
    {
       // print_r($this->data);

       self::$fields= array_keys($this->data);
       foreach(self::$fields as $field)
       {
        if ($field == 'sign_up'){
            continue;
        }
        $value= $this->testimput($this->data[$field]);
        $value = $this->isEmpty($value,$field);   
        if($field == 'email') {
            $value = $this->isEmpty($value,$field);
            $value = $this->isValidEmail($value,$field);
        }
        if($field == 'password'){
            $value = $this->valid_password($value,$field);
        }          
       }
        
    }
}
?>